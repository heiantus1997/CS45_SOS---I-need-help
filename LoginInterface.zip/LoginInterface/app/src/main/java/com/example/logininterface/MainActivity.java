package com.example.logininterface;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //声明控件
   private Button ButtonLogin;
   private Button ButtonRegister;
   private EditText EtUser;
   private EditText EtPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //找到控件
       ButtonLogin=findViewById(R.id.button_login);
       ButtonRegister=findViewById(R.id.button_register);
       EtUser=findViewById(R.id.et_1);
       EtPassword=findViewById(R.id.et_2);

       //实现直接跳转（点击登录即跳转）
//        ButtonLogin.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                Intent intent = null;
//                intent = new Intent(MainActivity.this,FunctionActivity.class);
//                startActivity(intent);
//            }
//        });

        //Register按钮
        ButtonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = null;
                intent = new Intent(MainActivity.this,MainRegisterActivity.class);
                startActivity(intent);
            }
        });

        //Login按钮-匹配对应用户密码才能跳转
         ButtonLogin.setOnClickListener(this);
    }
    public void onClick(View v){
        //需要获取用户名和密码
        String username =EtUser.getText().toString();
        String password =EtPassword.getText().toString();
        Intent intent = null;

        //toast弹出的内容设置
        String success = "Login Successful";
        String fail = "Incorrect username or password, please try again.";

        //假设正确账号密码sjr 123456
        if(username.equals("sjr")&&password.equals("123456")){
            //toast 1.0
            //Toast.makeText(getApplicationContext(), success, Toast.LENGTH_SHORT).show();
            //toast center
            Toast toastLeft = Toast.makeText(getApplicationContext(), success, Toast.LENGTH_SHORT);
            toastLeft.setGravity(Gravity.CENTER,0,0);
            toastLeft.show();

            //如果正确则跳转
            intent = new Intent(MainActivity.this, StudentLoginActivity.class);
            startActivity(intent);
        }
        else{
            //如果错误，弹出登录失败
            //toast 2.0居中显示
            Toast toastCenter = Toast.makeText(getApplicationContext(),fail,Toast.LENGTH_SHORT);
            toastCenter.setGravity(Gravity.CENTER,0,0);
            toastCenter.show();
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
