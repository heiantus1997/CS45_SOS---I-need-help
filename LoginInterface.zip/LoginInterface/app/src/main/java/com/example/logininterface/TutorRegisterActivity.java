package com.example.logininterface;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class TutorRegisterActivity extends AppCompatActivity {

    //声明控件
    private Button ButtonBack3;
    private Button ButtonNext3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_register);
        //找到控件
        ButtonBack3 = findViewById(R.id.button_back3);
        ButtonNext3 = findViewById(R.id.button_next3);

        //选择back
        ButtonBack3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = null;
                intent = new Intent(TutorRegisterActivity.this,MainRegisterActivity.class);
                startActivity(intent);
            }
        });
        //选择next
        ButtonNext3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = null;
                intent = new Intent(TutorRegisterActivity.this,TutorLoginActivity.class);
                startActivity(intent);
            }
        });
    }
}