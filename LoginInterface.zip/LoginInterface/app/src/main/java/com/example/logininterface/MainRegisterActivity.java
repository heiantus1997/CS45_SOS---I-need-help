package com.example.logininterface;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainRegisterActivity extends AppCompatActivity {
    //声明控件
    private Button ButtonStudent;
    private Button ButtonTutor;
    private Button ButtonBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //找到控件
        ButtonStudent = findViewById(R.id.button_student);
        ButtonTutor = findViewById(R.id.button_tutor);
        ButtonBack = findViewById(R.id.button_back);

        //选择Student
        ButtonStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = null;
                intent = new Intent(MainRegisterActivity.this,StudentRegisterActivity.class);
                startActivity(intent);
            }
        });
        //选择Tutor
        ButtonTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = null;
                intent = new Intent(MainRegisterActivity.this,TutorRegisterActivity.class);
                startActivity(intent);
            }
        });
        //选择Back
        ButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = null;
                intent = new Intent(MainRegisterActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
}